import React from 'react';
import { Link } from 'react-router-dom';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { formatDistanceToNow } from 'date-fns';

interface VideoCardProps {
  video: {
    _id: string;
    title: string;
    description: string;
    thumbnail: string;
    videoFile: string;
    duration: number;
    views: number;
    isPublished: boolean;
    owner: {
      _id: string;
      username: string;
      fullName: string;
      avatar: string;
    };
    createdAt: string;
  };
}

const formatDuration = (seconds: number): string => {
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);

  if (hrs > 0) {
    return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
  return `${mins}:${secs.toString().padStart(2, '0')}`;
};

const formatViews = (views: number): string => {
  if (views >= 1000000) {
    return `${(views / 1000000).toFixed(1)}M`;
  }
  if (views >= 1000) {
    return `${(views / 1000).toFixed(1)}K`;
  }
  return views.toString();
};

export const VideoCard: React.FC<VideoCardProps> = ({ video }) => {
  return (
    <div className="flex flex-col gap-3">
      <Link to={`/video/${video._id}`} className="relative aspect-video rounded-lg overflow-hidden bg-muted group">
        <img
          src={video.thumbnail}
          alt={video.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
        />
        <div className="absolute bottom-2 right-2 bg-black/80 text-white px-1.5 py-0.5 rounded text-xs">
          {formatDuration(video.duration)}
        </div>
      </Link>

      <div className="flex gap-3">
        <Link to={`/channel/${video.owner.username}`}>
          <Avatar className="size-9">
            <AvatarImage src={video.owner.avatar} alt={video.owner.fullName} />
            <AvatarFallback>{video.owner.fullName.charAt(0)}</AvatarFallback>
          </Avatar>
        </Link>

        <div className="flex-1 min-w-0">
          <Link to={`/video/${video._id}`}>
            <h3 className="font-medium line-clamp-2 hover:text-primary">
              {video.title}
            </h3>
          </Link>
          <Link to={`/channel/${video.owner.username}`}>
            <p className="text-sm text-muted-foreground hover:text-foreground">
              {video.owner.fullName}
            </p>
          </Link>
          <p className="text-sm text-muted-foreground">
            {formatViews(video.views)} views • {formatDistanceToNow(new Date(video.createdAt), { addSuffix: true })}
          </p>
        </div>
      </div>
    </div>
  );
};
